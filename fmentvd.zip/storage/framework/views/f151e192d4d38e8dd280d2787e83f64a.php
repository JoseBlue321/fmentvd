<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('partials.cabeza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('verificacion.evento')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="" class="form-label">Codigo del Evento</label>
                                <input
                                    type="number"
                                    name="codigo"
                                    id=""
                                    class="form-control"
                                    placeholder=""
                                    aria-describedby="helpId"
                                    required
                                />
                                <small id="helpId" class="text-muted">Ingrese el codigo del evento</small>
                            </div>

                            <div class="mb-3">
                                <label for="" class="form-label">Carnet</label>
                                <input
                                    type="text"
                                    name="carnet"
                                    id=""
                                    class="form-control"
                                    placeholder=""
                                    aria-describedby="helpId"
                                    required
                                />
                                <small id="helpId" class="text-muted">Ingrese su carnet de identidad</small>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                Iniciar
                            </button>
                          <a class="btn btn-danger" href="<?php echo e(route('certificados')); ?>" role="button">Cancelar</a>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
 
    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\fmentvd\resources\views/certificados/evento.blade.php ENDPATH**/ ?>