<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('partials.cabeza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <h4 class="text-center">CERTIFICADOS DISPONIBLES</h4>
            <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">

                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title"> <?php echo e($participante->nombre); ?> <?php echo e($participante->paterno); ?> <?php echo e($participante->materno); ?> - <?php echo e($participante->carnet); ?></h6>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Evento</th>
                                        <th>Detalle</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($participante->evento); ?></td>
                                        <td><?php echo e($participante->detalle); ?></td>
                                        <td><?php echo e($participante->fecha); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="card-text">
                <br>
                <a class="btn btn-danger" type="button" href="<?php echo e(route('historial.evento')); ?>" role="button">Salir</a>
            </p>

        </div>
    </div>











    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\fmentvd\resources\views/certificados/checkhistorial.blade.php ENDPATH**/ ?>