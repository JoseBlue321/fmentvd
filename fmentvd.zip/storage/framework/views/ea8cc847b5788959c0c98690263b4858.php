<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('partials.cabeza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-12">

            </div>
        </div>
    </div>





    

    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\fmentvd\resources\views/persona.blade.php ENDPATH**/ ?>