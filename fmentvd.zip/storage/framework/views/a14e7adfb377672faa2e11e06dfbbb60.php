<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('partials.cabeza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container">
        <div class="row align-items-center justify-content-center">
            <?php $__currentLoopData = $validaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-10">

                <div class="card">
                    <div class="card-body">
                        <div class="alert alert-success" role="alert">
                            <strong><h4 class="card-title"> <?php echo e($validacion->nombre); ?> <?php echo e($validacion->paterno); ?> <?php echo e($validacion->materno); ?> - <?php echo e($validacion->carnet); ?></h4></strong> 
                            Su Certifficado es VALIDO que se otorgo en el siguiente evento
                            
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Codigo</th>
                                        <th>Evento</th>
                                        <th>Detalle</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($validacion->codigo); ?></td>
                                        <td><?php echo e($validacion->evento); ?></td>
                                        <td><?php echo e($validacion->detalle); ?></td>
                                        <td><?php echo e($validacion->fecha); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                </div>
                <br>
                <p class="card-text">
                    <a class="btn btn-danger" type="button" href="<?php echo e(route('validacion.evento')); ?>" role="button">Salir</a>
                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>





    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\fmentvd\resources\views/certificados/check.blade.php ENDPATH**/ ?>