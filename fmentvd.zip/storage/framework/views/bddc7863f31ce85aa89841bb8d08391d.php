<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('partials.cabeza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
      <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row justify-content-center align-items-center">
            <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"><?php echo e($persona->paterno); ?> <?php echo e($persona->materno); ?> <?php echo e($persona->nombre); ?> - <?php echo e($persona->carnet); ?></h4>

                    <table class="table table-hover">
                      <thead class="table-dark">
                        <tr>
                          <th>Carrera</th>
                          <th>Curso</th>
                          <th>Asignatura</th>
                          <th>parcial</th>
                          <th>nota</th>
                          <th>imagen y patron</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $persona->evaluaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($evaluacion->parciales->asignaturas->cursos->carreras->carrera); ?></td>
                          <td><?php echo e($evaluacion->parciales->asignaturas->cursos->anio); ?></td>
                          <td><?php echo e($evaluacion->parciales->asignaturas->nombre); ?></td>
                          <td><?php echo e($evaluacion->parciales->parcial); ?></td>
                          <td><?php echo e($evaluacion->nota); ?></td>
                          <td>
                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('img.persona',$evaluacion->id)); ?>" role="button">ver hoja y patron de respuesta</a>
                          </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>          

                  </div>
                </div>
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <a name="" id="" class="btn btn-danger" href="<?php echo e(route('calificaciones')); ?>" role="button">Salir</a> <br>
    </div>


    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\fmentvd\resources\views/calificaciones/asignatura.blade.php ENDPATH**/ ?>