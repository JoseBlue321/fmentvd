<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('partials.cabeza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row align-items-start justify-content-start">
            <div class="col-md-8">
                <div class="card">
                    <img class="card-img-top" src="holder.js/100x180/" alt="">
                    <div class="card-body">
                        <h4 class="card-title text-center">RECOPILACIÓN DE DATOS</h4>
                        <p class="card-text"></p>
                        <table class="table">
                            <thead class="table-dark">
                                <tr>
                                    <th>Categoria</th>
                                    <th>Registro</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Proyectos de: Investigación/Interacción Social/Extensión Universitaria</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('proyectos.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Artículos científicos, otro tipo de publicación</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('articulos.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Libros</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('libros.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Tesis realizadas en el Instituto por cursantes/por miembros del Instituto/Tuteladas en el Instituto</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('tesis.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Aportes (de participantes) en Congresos Científicos, Simposios, Conferencias, Jornadas, Eventos de Investigación por los Institutos</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('aportes.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Organizadores de Simposios, Conferencias, Jornadas, Eventos de Investigación por los Institutos</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('organizadores.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Patentes</td>
                                    <td>
                                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('patentes.memorias')); ?>" role="button">Registrar</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
              </div>
        </div>
    </div>





    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\fmentvd\resources\views/memorias.blade.php ENDPATH**/ ?>