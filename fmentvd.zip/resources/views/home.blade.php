<!DOCTYPE html>
<html lang="en">
    @include('partials.head')
<body>
    @include('partials.cabeza')
    @include('partials.nav')

    @include('home.main')

    @include('partials.footer')
    @include('partials.js')
</body>
</html>