<!DOCTYPE html>
<html lang="en">
    @include('partials.head')
<body>
    @include('partials.cabeza')
    @include('partials.nav')

    <div class="container">
        <div class="row align-items-start justify-content-start">
            <div class="col-md-12">
                Documentos
              </div>
        </div>
    </div>





    @include('partials.js')
</body>
</html>