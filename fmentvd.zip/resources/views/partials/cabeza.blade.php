<nav class="navbar navbar-light">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-2">
          <a class="navbar-brand" href="#">
            <img src="{{ asset('img/logo_medicina.png')}}" alt="" width="120" height="120" class="d-inline-block align-text-top">
          </a>
        </div>
        <div class="col-md-10">
          <p class="fs-5 fst-normal m-0">UNIVERSIDAD MAYOR DE SAN ANDRÉS</p>
          <p class="fs-6 fw-normal m-0">FACULTAD DE MEDICINA, ENFERMERÍA, NUTRICIÓN Y TECNOLOGÍA MÉDICA</p>
          <p class="fs-6 fw-bold m-0">VICEDECANATO</p>
          <p>Av. Saavedra Nro. 2246 - Miraflores - 2612371</p>
        </div>
      </div>
    </div>
  </nav>
